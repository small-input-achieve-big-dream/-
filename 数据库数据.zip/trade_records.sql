INSERT INTO `trade_records` VALUES (4, '1', '34', '123.00', '2019-6-24 05:39:18');
INSERT INTO `trade_records` VALUES (2, '1', '32', '322.00', '2019-6-17 05:08:06');
INSERT INTO `trade_records` VALUES (3, '1', '33', '32.00', '2019-6-24 05:15:42');
INSERT INTO `trade_records` VALUES (13, '2', '39', '2323.00', '2019-6-24 07:07:18');
INSERT INTO `trade_records` VALUES (12, '1', '38', '123.00', '2019-6-24 06:31:57');
INSERT INTO `trade_records` VALUES (14, '4', '41', '232.00', '2019-6-24 08:32:10');
INSERT INTO `trade_records` VALUES (15, '5', '42', '2323.00', '2019-6-24 08:53:15');
