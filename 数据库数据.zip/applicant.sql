INSERT INTO `applicant` VALUES (1, '1', '江一帆', '440104199807122812', 0, '中海', 0);
INSERT INTO `applicant` VALUES (2, '2', '郭兆言', '237951196806291536', 0, 'china', 0);
INSERT INTO `applicant` VALUES (3, '3', '汤志新', '214408197608270677', 0, 'china', 0);
INSERT INTO `applicant` VALUES (4, '4', '张建', '330552198708271890', 0, 'china', 0);
INSERT INTO `applicant` VALUES (5, '5', '张亚军', '549156196909082612', 0, 'china', 0);
