INSERT INTO `compensate_records` VALUES (1, 33, '2019-6-24 06:42:39', 37, '1');
INSERT INTO `compensate_records` VALUES (2, 33, '2019-6-24 06:45:41', 37, '1');
INSERT INTO `compensate_records` VALUES (3, 33, '2019-6-24 06:46:20', 37, '1');
INSERT INTO `compensate_records` VALUES (4, 33, '2019-6-24 06:47:19', 37, '1');
INSERT INTO `compensate_records` VALUES (5, 41, '2019-6-24 08:36:16', 266, '4');
