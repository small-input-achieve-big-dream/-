INSERT INTO `recognizee_infor` VALUES (1, '440104199807122812', '江一帆');
INSERT INTO `recognizee_infor` VALUES (2, '237951196806291536', '郭兆言');
