INSERT INTO `complaininfor` VALUES (1, '1', '理赔条件不合理', 'hello\r\n', 0, 'None', '-', '2019-6-23 23:48:08', '2019-6-23 23:48:08');
INSERT INTO `complaininfor` VALUES (2, '1', '理赔条件不合理', '123213', 0, 'None', '-', '2019-6-24 05:41:35', '2019-6-24 05:41:35');
INSERT INTO `complaininfor` VALUES (3, '1', '理赔条件不合理', '1232132323', 0, 'None', '-', '2019-6-24 05:41:52', '2019-6-24 05:41:52');
INSERT INTO `complaininfor` VALUES (4, '1', '理赔条件不合理', '1232132323', 0, 'None', '-', '2019-6-24 05:43:43', '2019-6-24 05:43:43');
INSERT INTO `complaininfor` VALUES (5, '1', '理赔条件不合理', '213', 0, 'None', '-', '2019-6-24 05:45:09', '2019-6-24 05:45:09');
INSERT INTO `complaininfor` VALUES (6, '2', '理赔条件不合理', '1232131', 0, 'None', '-', '2019-6-24 06:57:58', '2019-6-24 06:57:58');
INSERT INTO `complaininfor` VALUES (7, '4', '拒赔理由不充分', '213213', 0, 'None', '-', '2019-6-24 08:55:37', '2019-6-24 08:55:37');
