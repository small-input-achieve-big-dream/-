INSERT INTO `accident_application` VALUES (1, 1, 32, '123123213213', 0, 21323, 'static/1_xRB3Gn1.jpg', '1.jpg');
INSERT INTO `accident_application` VALUES (34, 2, 39, '21312', 1, 2323, 'static/27ed6e896edca63d7759e8b6727b1d08_JhmsKAw.jpg', '27ed6e896edca63d7759e8b6727b1d08.jpg');
INSERT INTO `accident_application` VALUES (35, 4, 41, '21321323', 0, 232, 'static/27ed6e896edca63d7759e8b6727b1d08_uqHBXIm.jpg', '27ed6e896edca63d7759e8b6727b1d08.jpg');
INSERT INTO `accident_application` VALUES (36, 5, 42, '23123', 0, 2323, 'static/27ed6e896edca63d7759e8b6727b1d08_Xw3rYnI.jpg', '27ed6e896edca63d7759e8b6727b1d08.jpg');
